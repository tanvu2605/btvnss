<template>
  <div>
    Bai1: <bai1 /><br />
    Bai2: <bai2 /><br />
    Bai3: <bai3 /><br />
    Bai4: <bai4 /><br />
    Bai5: <bai5 /><br />
    Bai7: <bai7 /><br />
    Bai8: <bai8 /><br />
    Bai9: <bai9 /><br />
  </div>
</template>

<script setup>
import bai1 from "./components/bai1.vue";
import bai2 from "./components/bai2.vue";
import bai3 from "./components/bai3.vue";
import bai4 from "./components/bai4.vue";
import bai5 from "./components/bai5.vue";
import bai7 from "./components/bai7.vue";
import bai8 from "./components/bai8.vue";
import bai9 from "./components/bai9.vue";
</script>

<style></style>